/**
  
 @author  
 */
public class Date 
{
   private int  day;
   private int  month;
   private int  year;
   
   public Date(String d)
   {
      //use StringTokenizer to parse the String and create a Date object     
   }
   
   public Date(Date d)
   {
      //this is a constructor
   }      
   
   public boolean isValid()
   {
       
   }
   
   @Override
   public String toString()
   {
       //use the format "month/day/year"
   }
   
   @Override
   public boolean equals(Object obj)
   {
       
   }  
}


