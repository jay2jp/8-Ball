/**
  
 @author  
 */
public class Team 
{
   private final int NOT_FOUND = -1;
   private final int GROW_SIZE = 4; //initial and grow size
   private TeamMember [] team;
   private int numMembers;
   
   public Team()
   {
      //this is the default constructor
   }
   
   private int find(TeamMember m)
   {
       
   }
   
   private void grow()
   {
       
   }
   
   public boolean isEmpty()
   {
       
   }
   
   public void add(TeamMember m)
   {     
            
   }
   
   public boolean remove(TeamMember m)
   {
       
   } 
   
   public boolean contains(TeamMember m)
   {
      
   } 
   
   public void print()
   {
      //set up a for loop and call the toString() method
   } 
}
